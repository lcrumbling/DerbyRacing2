# to-array

Turn an array like into an array

## Example

``` js
var toArray = require("to-array")
    , elems = document.links

var array = toArray(elems)
```

## Installation

`npm install to-array`

## Contributors

 - Raynos

## MIT Licenced
